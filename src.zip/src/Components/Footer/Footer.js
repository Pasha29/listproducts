import React from 'react';
import s from './Footer.module.css';

const Footer = () => {
    return (
        <div className={s.container}></div>
    );
}

export default Footer;